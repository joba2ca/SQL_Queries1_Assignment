create function getR (x DOUBLE, y DOUBLE)
    RETURNS DOUBLE
BEGIN
    RETURN sqrt(x*x*y*y);
END;

